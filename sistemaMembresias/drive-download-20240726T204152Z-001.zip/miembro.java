package clases;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class miembro extends persona{
    Scanner s = new Scanner(System.in);
    private String fechaRegistro;
    private String numTel;
    private int empleado;
    //conexion a la BD
    private conexion conexion;
    public miembro(conexion conexion) {
        this.conexion = conexion;
    }
    public void verRegistros() throws SQLException{
        Connection con = conexion.conectar();
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM miembro");
        System.out.println("\n\t//////////// DATOS DE LOS MIEMBROS ////////////\n");
        while (rs.next()) {
            System.out.println("---------------------------------------------------------------");
            System.out.println("Numero: "+rs.getInt("numero"));
            System.out.println("Fecha de registro: "+rs.getDate("fechaRegistro"));
            System.out.println("Numero de telefono: "+rs.getString("numTel")+" ");
            System.out.println("Nombre: "+rs.getString("nombre")+ " "+rs.getString("primerApellido")+ " "+rs.getString("segundoApellido"));
            System.out.println("Correo: "+rs.getString("correo")+" ");
            System.out.println("Empleado que lo registro: "+rs.getInt("empleado"));

            System.out.println("---------------------------------------------------------------\n\n");
        }
    }

    public void verUnRegistros() throws SQLException{ 
        Connection con = conexion.conectar();
        Statement st = con.createStatement();
        System.out.println("Ingrese el numero del empleado del cual desea ver su informacion");
        setNumero(s.nextInt());
        ResultSet rs = st.executeQuery("SELECT * FROM miembro WHERE numero = '"+getNumero()+"' ");

        /*
        Falta agregar un modo de evaluar si hay resultados de la consulta o no, para con esto evitar que se imprima solamente un salto de linea
        */
        System.out.println("\n\t//////////// DATOS DE LOS MIEMBROS ////////////\n");
        while (rs.next()) {
            System.out.println("---------------------------------------------------------------");
            System.out.println("Numero: "+rs.getInt("numero"));
            System.out.println("Fecha de registro: "+rs.getDate("fechaRegistro"));
            System.out.println("Numero de telefono: "+rs.getString("numTel")+" ");
            System.out.println("Nombre: "+rs.getString("nombre")+ " "+rs.getString("primerApellido")+ " "+rs.getString("segundoApellido"));
            System.out.println("Correo: "+rs.getString("correo")+" ");
            System.out.println("Empleado que lo registro: "+rs.getInt("empleado"));

            System.out.println("---------------------------------------------------------------\n\n");
        }
    }
    
    public void agregarRegistro() throws SQLException{
        Connection con = conexion.conectar();
        Statement st = con.createStatement();
        System.out.println("- - - - AÑADIR MIEMBRO - - - - - ");
        System.out.println("Ingrese el nombre de pila: ");
        setNombre(s.nextLine());
        System.out.println("Ingrese el primer apellido: ");
        setPrimer_AP(s.nextLine());
        System.out.println("Ingrese el segundo apellido: ");
        setSegundo_AP(s.nextLine());
        System.out.println("Ingrese el correo: ");
        setCorreo(s.nextLine());
        System.out.println("Ingrese el numero de telefono: ");
        numTel = s.nextLine();
        System.out.println("Ingrese el numero del empleado que lo afilio: ");
        empleado = s.nextInt();
        s.nextLine();
        System.out.println("Introduce la fecha (formato yyyy-MM-dd): ");
        fechaRegistro = s.nextLine();
        // Convertir la fecha ingresada por el usuario a LocalDate
        LocalDate fecha = null;
            try {
                fecha = LocalDate.parse(fechaRegistro, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            } catch (DateTimeParseException e) {
                System.out.println("Formato de fecha incorrecto. Por favor usa el formato yyyy-MM-dd.");
                return;
            }
        String comando = "INSERT INTO miembro(fechaRegistro, numTel, nombre, primerApellido, segundoApellido, correo, empleado) values ('" +fecha+ "','" + numTel + "','"+getNombre()+"','"+getPrimer_AP()+"','"+getSegundo_AP()+"','"+getCorreo()+"', '"+empleado+"')";
        st.executeUpdate(comando);
        System.out.println(" - - - USUARIO REGISTRADO DE FORMA EXITOSA - - - ");
    }

    public void deleteMiemb() throws SQLException{
        Connection con = conexion.conectar();
        Statement st = con.createStatement();
        System.out.println("- - - - ELIMINAR MIEMBRO - - - - - ");
        System.out.println("Ingrese el numero de Miembro a eliminar.");
        setNumero(s.nextInt());
        String comando = "DELETE FROM miembro WHERE numero = '"+getNumero()+"'";
        st.executeUpdate(comando);
        System.out.println(" - - - USUARIO ELIMINADO DE FORMA EXITOSA - - - ");
    }
}
