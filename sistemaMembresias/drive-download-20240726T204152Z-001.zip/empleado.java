package clases;
import java.sql.*;
import java.util.Scanner;

public class empleado extends persona{
    Scanner s = new Scanner(System.in);
    private String contrasenia;
    private String puesto;
    //conexion a la BD
    private conexion conexion;
    public empleado(conexion conexion) {
        this.conexion = conexion;
    }

    public void verRegistros() throws SQLException{ // Metodo para ver todos los registros de empleados
        Connection con = conexion.conectar();
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM empleado");
        System.out.println("\n\t//////////// DATOS DE LOS EMPLEADOS ////////////\n");
        while (rs.next()) {
            System.out.println("---------------------------------------------------------------");
            System.out.println("Numero del empleado: "+rs.getInt("numero"));
            System.out.println("Puesto del empleado: "+rs.getString("puesto"));
            System.out.println(" - - - DATOS PERSONALES - - - ");
            System.out.println("Correo: "+rs.getString("correo")+" ");
            System.out.println("Contraseña: "+rs.getString("contrasenia")+" ");
            System.out.println("Nombre: "+rs.getString("nombre")+ " "+rs.getString("primerApellido")+ " "+rs.getString("segundoApellido"));

            System.out.println("---------------------------------------------------------------\n\n");
        }
    }

    public void verUnRegistros() throws SQLException{ // Metodo para ver todos los registros de empleados
        Connection con = conexion.conectar();
        Statement st = con.createStatement();
        System.out.println("Ingrese el numero del empleado del cual desea ver su informacion");
        setNumero(s.nextInt());
        ResultSet rs = st.executeQuery("SELECT * FROM empleado WHERE numero = '"+getNumero()+"' ");
        /*
        Falta agregar un modo de evaluar si hay resultados de la consulta o no, para con esto evitar que se imprima solamente un salto de linea
         */
        System.out.println("\n\t//////////// DATOS DE LOS EMPLEADOS ////////////\n");
        while (rs.next()) {
            System.out.println("---------------------------------------------------------------");
            System.out.println("Numero del empleado: "+rs.getInt("numero"));
            System.out.println("Puesto del empleado: "+rs.getString("puesto"));
            System.out.println(" - - - DATOS PERSONALES - - - ");
            System.out.println("Correo: "+rs.getString("correo")+" ");
            System.out.println("Contraseña: "+rs.getString("contrasenia")+" ");
            System.out.println("Nombre: "+rs.getString("nombre")+ " "+rs.getString("primerApellido")+ " "+rs.getString("segundoApellido"));

            System.out.println("---------------------------------------------------------------\n\n");
        }
    }

    public void agregarEmpld() throws SQLException{
        Connection con = conexion.conectar();
        Statement st = con.createStatement();
        System.out.println("- - - - AÑADIR EMPLEADO - - - - - ");
        System.out.println("Ingrese el nombre de pila: ");
        setNombre(s.nextLine());
        System.out.println("Ingrese el primer apellido: ");
        setPrimer_AP(s.nextLine());
        System.out.println("Ingrese el segundo apellido: ");
        setSegundo_AP(s.nextLine());
        System.out.println("Ingrese el correo: ");
        setCorreo(s.nextLine());
        System.out.println("Ingrese la contraseña: ");
        contrasenia = s.nextLine();
        System.out.println("Ingrese el puesto: ");
        puesto = s.nextLine();
        s.nextLine();
        String comando = "INSERT INTO empleado(correo, contrasenia, nombre, primerApellido, segundoApellido, puesto) values ('" + getCorreo() + "','" + contrasenia + "','"+getNombre()+"','"+getPrimer_AP()+"','"+getSegundo_AP()+"','"+puesto+"')";
        st.executeUpdate(comando);
        
        System.out.println(" - - - USUARIO REGISTRADO DE FORMA EXITOSA - - - ");
    }

    public void updateEmpld() throws SQLException{
        Connection con = conexion.conectar();
        Statement st = con.createStatement();
        System.out.println("- - - - ACTUALIZAR EMPLEADO - - - - - ");
        System.out.println("Ingrese el numero del empleado a actualizar: ");
        setNumero(s.nextInt());
        s.nextLine();
        System.out.println("Ingrese el nombre de pila: ");
        setNombre(s.nextLine());
        System.out.println("Ingrese el primer apellido: ");
        setPrimer_AP(s.nextLine());
        System.out.println("Ingrese el segundo apellido: ");
        setSegundo_AP(s.nextLine());
        System.out.println("Ingrese el correo: ");
        setCorreo(s.nextLine());
        System.out.println("Ingrese la contraseña: ");
        contrasenia = s.nextLine();
        System.out.println("Ingrese el puesto: ");
        puesto = s.nextLine();
        // String comando = "UPTADE empleado(correo, contrasenia, nombre, primerApellido, segundoApellido, puesto) values ('" + getCorreo() + "','" + contrasenia + "','"+getNombre()+"','"+getPrimer_AP()+"','"+getSegundo_AP()+"','"+puesto+"') ";
        String comando = "UPDATE empleado SET " +
                         "correo = '" + getCorreo() + "', " +
                         "contrasenia = '" + contrasenia + "', " +
                         "nombre = '" + getNombre() + "', " +
                         "primerApellido = '" + getPrimer_AP() + "', " +
                         "segundoApellido = '" + getSegundo_AP() + "', " +
                         "puesto = '" + puesto + "' " +
                         "WHERE numero = " + getNumero();
        st.executeUpdate(comando);
        
        System.out.println(" - - - ACTUALIZACION EXITOSA - - - ");
    }

    public void deleteEmpld() throws SQLException{
        Connection con = conexion.conectar();
        Statement st = con.createStatement();
        System.out.println("- - - - ELIMINAR EMPLEADO - - - - - ");
        System.out.println("Ingrese el numero de empleado a eliminar.");
        setNumero(s.nextInt());
        String comando = "DELETE FROM empleado WHERE numero = '"+getNumero()+"'";
        st.executeUpdate(comando);
        System.out.println(" - - - USUARIO ELIMINADO DE FORMA EXITOSA - - - ");
    }
}
